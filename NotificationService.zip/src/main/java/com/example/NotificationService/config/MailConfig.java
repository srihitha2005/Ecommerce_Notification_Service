package com.example.NotificationService.config;

public class MailConfig {
}
